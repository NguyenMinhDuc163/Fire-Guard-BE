create function trigger_update_rankings() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Cập nhật xếp hạng sách
    INSERT INTO book_rankings (book_id, views, avg_rating, review_count, favorite_count, ranking_score, category_id, last_calculated)
    SELECT
        b.book_id,
        b.views,
        COALESCE((SELECT AVG(rating::numeric) FROM book_reviews WHERE book_id = b.book_id), 0) AS avg_rating,
        COALESCE((SELECT COUNT(*) FROM book_reviews WHERE book_id = b.book_id), 0) AS review_count,
        COALESCE((SELECT COUNT(*) FROM user_favorites WHERE book_id = b.book_id), 0) AS favorite_count,
        -- Công thức tính điểm
        b.views +
        (COALESCE((SELECT AVG(rating::numeric) FROM book_reviews WHERE book_id = b.book_id), 0) * 10) +
        (COALESCE((SELECT COUNT(*) FROM user_favorites WHERE book_id = b.book_id), 0) * 2) AS ranking_score,
        b.category_id,
        CURRENT_TIMESTAMP
    FROM
        books b
    WHERE
       -- Nếu trigger từ books, chỉ cập nhật sách đó
        (TG_TABLE_NAME = 'books' AND b.book_id = NEW.book_id)
       -- Nếu trigger từ book_reviews, chỉ cập nhật sách đó
       OR (TG_TABLE_NAME = 'book_reviews' AND b.book_id = NEW.book_id)
       -- Nếu trigger từ user_favorites, chỉ cập nhật sách đó
       OR (TG_TABLE_NAME = 'user_favorites' AND b.book_id = NEW.book_id)
    ON CONFLICT (book_id) DO UPDATE
        SET
            views = EXCLUDED.views,
            avg_rating = EXCLUDED.avg_rating,
            review_count = EXCLUDED.review_count,
            favorite_count = EXCLUDED.favorite_count,
            ranking_score = EXCLUDED.ranking_score,
            category_id = EXCLUDED.category_id,
            last_calculated = EXCLUDED.last_calculated;

    -- Cập nhật xếp hạng
    WITH ranked_books AS (
        SELECT
            book_id,
            RANK() OVER (ORDER BY ranking_score DESC) as overall_rank,
            RANK() OVER (PARTITION BY category_id ORDER BY ranking_score DESC) as category_rank
        FROM book_rankings
    )
    UPDATE book_rankings br
    SET
        overall_rank = rb.overall_rank,
        daily_rank = rb.category_rank
    FROM ranked_books rb
    WHERE br.book_id = rb.book_id;

    -- Cập nhật author_rankings từ sách được đề cập
    INSERT INTO author_rankings (author_id, total_books, total_views, avg_rating, total_favorites, author_score, last_calculated)
    SELECT
        a.author_id,
        COUNT(DISTINCT b.book_id) AS total_books,
        COALESCE(SUM(b.views), 0) AS total_views,
        COALESCE(AVG((SELECT AVG(rating::numeric) FROM book_reviews WHERE book_id = b.book_id)), 0) AS avg_rating,
        COALESCE((SELECT COUNT(*) FROM user_favorites uf JOIN books b2 ON uf.book_id = b2.book_id
                  WHERE b2.author_id = a.author_id), 0) AS total_favorites,
        -- Công thức tính điểm cho tác giả
        COUNT(DISTINCT b.book_id) * 5 +
        COALESCE(SUM(b.views), 0) * 0.01 +
        COALESCE((SELECT COUNT(*) FROM user_favorites uf JOIN books b2 ON uf.book_id = b2.book_id
                  WHERE b2.author_id = a.author_id), 0) * 2 +
        COALESCE(AVG((SELECT AVG(rating::numeric) FROM book_reviews WHERE book_id = b.book_id)), 0) * 10 AS author_score,
        CURRENT_TIMESTAMP
    FROM
        authors a
            JOIN
        books b ON a.author_id = b.author_id
    WHERE
       -- Cập nhật tác giả liên quan đến sách thay đổi
        (TG_TABLE_NAME = 'books' AND b.book_id = NEW.book_id)
       OR (TG_TABLE_NAME = 'book_reviews' AND b.book_id = NEW.book_id)
       OR (TG_TABLE_NAME = 'user_favorites' AND b.book_id = NEW.book_id)
    GROUP BY
        a.author_id
    ON CONFLICT (author_id) DO UPDATE
        SET
            total_books = EXCLUDED.total_books,
            total_views = EXCLUDED.total_views,
            avg_rating = EXCLUDED.avg_rating,
            total_favorites = EXCLUDED.total_favorites,
            author_score = EXCLUDED.author_score,
            last_calculated = EXCLUDED.last_calculated;

    -- Cập nhật xếp hạng cho tác giả
    WITH ranked_authors AS (
        SELECT
            author_id,
            RANK() OVER (ORDER BY author_score DESC) as overall_rank
        FROM author_rankings
    )
    UPDATE author_rankings ar
    SET overall_rank = ra.overall_rank
    FROM ranked_authors ra
    WHERE ar.author_id = ra.author_id;

    -- Thêm lịch sử xếp hạng hàng ngày nếu chưa có
    INSERT INTO book_ranking_history (book_id, ranking_date, ranking_score, rank_position, period_type)
    SELECT book_id, CURRENT_DATE, ranking_score, overall_rank, 'daily'
    FROM book_rankings
    WHERE
        book_id IN (
            SELECT book_id FROM books
            WHERE (TG_TABLE_NAME = 'books' AND book_id = NEW.book_id)
               OR (TG_TABLE_NAME = 'book_reviews' AND book_id = NEW.book_id)
               OR (TG_TABLE_NAME = 'user_favorites' AND book_id = NEW.book_id)
        )
      AND NOT EXISTS (
        SELECT 1 FROM book_ranking_history
        WHERE book_id = book_rankings.book_id
          AND ranking_date = CURRENT_DATE
          AND period_type = 'daily'
    )
    ON CONFLICT (book_id, ranking_date, period_type)
        DO UPDATE SET
                      ranking_score = EXCLUDED.ranking_score,
                      rank_position = EXCLUDED.rank_position;

    RETURN NULL;
END;
$$;

alter function trigger_update_rankings() owner to postgres;

