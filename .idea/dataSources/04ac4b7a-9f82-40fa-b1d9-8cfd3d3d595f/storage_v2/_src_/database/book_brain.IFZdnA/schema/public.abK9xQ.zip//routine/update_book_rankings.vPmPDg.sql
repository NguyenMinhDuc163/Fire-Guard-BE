create function update_book_rankings() returns void
    language plpgsql
as
$$
BEGIN
    -- Cập nhật hoặc thêm mới xếp hạng sách
    INSERT INTO book_rankings (
        book_id, views, avg_rating, review_count, favorite_count,
        ranking_score, category_id, last_calculated
    )
    SELECT
        b.book_id,
        b.views,
        COALESCE(AVG(br.rating), 0) AS avg_rating,
        COUNT(DISTINCT br.user_id) AS review_count,
        COUNT(DISTINCT uf.id) AS favorite_count,
        -- Công thức tính điểm (có thể điều chỉnh)
        (COALESCE(AVG(br.rating), 0) * 10) +
        (COUNT(DISTINCT uf.id) * 2) +
        (b.views * 0.01) AS ranking_score,
        b.category_id,
        CURRENT_TIMESTAMP
    FROM
        books b
            LEFT JOIN
        book_reviews br ON b.book_id = br.book_id
            LEFT JOIN
        user_favorites uf ON b.book_id = uf.book_id
    GROUP BY
        b.book_id, b.views, b.category_id
    ON CONFLICT (book_id)
        DO UPDATE SET
                      views = EXCLUDED.views,
                      avg_rating = EXCLUDED.avg_rating,
                      review_count = EXCLUDED.review_count,
                      favorite_count = EXCLUDED.favorite_count,
                      ranking_score = EXCLUDED.ranking_score,
                      category_id = EXCLUDED.category_id,
                      last_calculated = CURRENT_TIMESTAMP;

    -- Cập nhật xếp hạng tổng thể
    UPDATE book_rankings
    SET overall_rank = ranks.rank
    FROM (
             SELECT book_id, RANK() OVER (ORDER BY ranking_score DESC) as rank
             FROM book_rankings
         ) ranks
    WHERE book_rankings.book_id = ranks.book_id;

    -- Cập nhật xếp hạng theo danh mục
    UPDATE book_rankings
    SET daily_rank = ranks.rank
    FROM (
             SELECT book_id, RANK() OVER (PARTITION BY category_id ORDER BY ranking_score DESC) as rank
             FROM book_rankings
         ) ranks
    WHERE book_rankings.book_id = ranks.book_id;

    -- Lưu lịch sử xếp hạng hàng ngày
    INSERT INTO book_ranking_history (
        book_id, ranking_date, ranking_score, rank_position, period_type
    )
    SELECT
        book_id, CURRENT_DATE, ranking_score, overall_rank, 'daily'
    FROM
        book_rankings
    ON CONFLICT (book_id, ranking_date, period_type)
        DO UPDATE SET
                      ranking_score = EXCLUDED.ranking_score,
                      rank_position = EXCLUDED.rank_position;

    -- Cập nhật xếp hạng tuần/tháng theo cách tương tự
    -- (Có thể thêm logic phức tạp hơn để tính xếp hạng tuần/tháng)
END;
$$;

alter function update_book_rankings() owner to postgres;

