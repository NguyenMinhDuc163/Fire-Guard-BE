create function update_book_rating() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Trường hợp xóa đánh giá
    IF TG_OP = 'DELETE' THEN
        UPDATE books
        SET rating = (
            SELECT COALESCE(ROUND(AVG(rating)::numeric, 2), 0)
            FROM book_reviews
            WHERE book_id = OLD.book_id
        ),
            updated_at = CURRENT_TIMESTAMP
        WHERE book_id = OLD.book_id;

        RETURN OLD;
    ELSE -- Trường hợp thêm hoặc cập nhật đánh giá
        UPDATE books
        SET rating = (
            SELECT COALESCE(ROUND(AVG(rating)::numeric, 2), 0)
            FROM book_reviews
            WHERE book_id = NEW.book_id
        ),
            updated_at = CURRENT_TIMESTAMP
        WHERE book_id = NEW.book_id;

        RETURN NEW;
    END IF;
END;
$$;

alter function update_book_rating() owner to postgres;

