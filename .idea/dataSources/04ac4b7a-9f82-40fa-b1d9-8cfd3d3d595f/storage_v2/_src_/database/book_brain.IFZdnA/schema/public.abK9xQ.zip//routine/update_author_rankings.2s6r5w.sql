create function update_author_rankings() returns void
    language plpgsql
as
$$
BEGIN
    -- Cập nhật hoặc thêm mới xếp hạng tác giả
    INSERT INTO author_rankings (
        author_id, total_books, total_views, avg_rating,
        total_favorites, author_score, last_calculated
    )
    SELECT
        a.author_id,
        COUNT(DISTINCT b.book_id) AS total_books,
        SUM(b.views) AS total_views,
        COALESCE(AVG(br.rating), 0) AS avg_rating,
        COUNT(DISTINCT uf.id) AS total_favorites,
        -- Công thức tính điểm cho tác giả
        (COUNT(DISTINCT b.book_id) * 5) +
        (COALESCE(AVG(br.rating), 0) * 10) +
        (COUNT(DISTINCT uf.id) * 2) +
        (SUM(b.views) * 0.005) AS author_score,
        CURRENT_TIMESTAMP
    FROM
        authors a
            LEFT JOIN
        books b ON a.author_id = b.author_id
            LEFT JOIN
        book_reviews br ON b.book_id = br.book_id
            LEFT JOIN
        user_favorites uf ON b.book_id = uf.book_id
    GROUP BY
        a.author_id
    ON CONFLICT (author_id)
        DO UPDATE SET
                      total_books = EXCLUDED.total_books,
                      total_views = EXCLUDED.total_views,
                      avg_rating = EXCLUDED.avg_rating,
                      total_favorites = EXCLUDED.total_favorites,
                      author_score = EXCLUDED.author_score,
                      last_calculated = CURRENT_TIMESTAMP;

    -- Cập nhật xếp hạng tổng thể
    UPDATE author_rankings
    SET overall_rank = ranks.rank
    FROM (
             SELECT author_id, RANK() OVER (ORDER BY author_score DESC) as rank
             FROM author_rankings
         ) ranks
    WHERE author_rankings.author_id = ranks.author_id;

    -- Lưu lịch sử xếp hạng hàng ngày
    INSERT INTO author_ranking_history (
        author_id, ranking_date, author_score, rank_position, period_type
    )
    SELECT
        author_id, CURRENT_DATE, author_score, overall_rank, 'daily'
    FROM
        author_rankings
    ON CONFLICT (author_id, ranking_date, period_type)
        DO UPDATE SET
                      author_score = EXCLUDED.author_score,
                      rank_position = EXCLUDED.rank_position;
END;
$$;

alter function update_author_rankings() owner to postgres;

