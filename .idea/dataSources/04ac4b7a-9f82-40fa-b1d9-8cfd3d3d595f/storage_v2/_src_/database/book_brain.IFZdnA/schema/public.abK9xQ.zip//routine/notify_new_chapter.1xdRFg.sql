create function notify_new_chapter() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Chèn thông báo cho tất cả người dùng đang theo dõi sách này
    INSERT INTO notifications (user_id, book_id, chapter_id, title, message, is_read)
    SELECT
        bs.user_id,
        NEW.book_id,
        NEW.chapter_id,
        CONCAT('Chương mới: ', NEW.title),
        CONCAT('Sách "', b.title, '" đã có chương mới: "', NEW.title, '"'),
        FALSE
    FROM book_subscriptions bs
             JOIN books b ON bs.book_id = b.book_id
    WHERE bs.book_id = NEW.book_id
      AND bs.is_active = TRUE;

    -- Cập nhật last_notified_at trong book_subscriptions
    UPDATE book_subscriptions
    SET last_notified_at = CURRENT_TIMESTAMP
    WHERE book_id = NEW.book_id
      AND is_active = TRUE;

    RETURN NEW;
END;
$$;

alter function notify_new_chapter() owner to postgres;

