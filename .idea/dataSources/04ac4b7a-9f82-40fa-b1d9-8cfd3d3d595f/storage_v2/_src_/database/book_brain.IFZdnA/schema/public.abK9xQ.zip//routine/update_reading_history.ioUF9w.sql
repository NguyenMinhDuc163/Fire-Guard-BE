create function update_reading_history() returns trigger
    language plpgsql
as
$$
begin
    -- Kiểm tra và cập nhật trạng thái đọc
    if new.completion_percentage >= 98 then
        -- Cập nhật hoặc tạo mới bản ghi lịch sử nếu đã đọc xong
        insert into reading_history (user_id, book_id, reading_status, finish_date)
        values (new.id, new.book_id, 'completed', CURRENT_TIMESTAMP)
        on conflict (user_id, book_id)
            do update set
                          reading_status = 'completed',
                          finish_date = CURRENT_TIMESTAMP,
                          times_read = reading_history.times_read +
                                       case when reading_history.reading_status = 'completed' then 1 else 0 end,
                          updated_at = CURRENT_TIMESTAMP;
    elsif new.completion_percentage > 0 then
        -- Cập nhật hoặc tạo mới bản ghi lịch sử nếu đang đọc
        insert into reading_history (user_id, book_id, reading_status, start_date)
        values (new.id, new.book_id, 'reading', CURRENT_TIMESTAMP)
        on conflict (user_id, book_id)
            do update set
                          reading_status = case
                                               when reading_history.reading_status = 'completed' then 'completed'
                                               else 'reading'
                              end,
                          start_date = coalesce(reading_history.start_date, CURRENT_TIMESTAMP),
                          updated_at = CURRENT_TIMESTAMP;
    end if;

    return new;
end;
$$;

alter function update_reading_history() owner to postgres;

